# Simple CLI Calculator
print("Welcome to Simple CLI Calculator")
is_running = True

while is_running:
    # Processing Calculations...
    print("Start Calculator processing")
    user_operation = input("what operation would you like to perform?\nPick any of: ['+', '-', '*', '/']")

    # Get user numbers
    try: # try to get user numbers, if they're valid integers/floats
      no1 = int(input("first number:"))
      no2 = int(input("second number:"))

    except: #we get an error when running it
        print("failed, invali numbers...")
        continue
     
    if   user_operation  == "+":
      #perform addition
       print(no1 + no2)
    elif user_operation == "*":
     #perform multiplication
     print(no1 * no2)
    elif user_operation == "/":
       #perform division
     print(no1 / no2)
    elif user_operation == "-":
      #perform subtraction
      print(no1 - no2)
 
    else:
       #invalid operation
        print("Invalid Operation, Try again...")

        Input("Would you like to run another Calculation, ['y,n']")
   
if   choice =="y":
    

  if choice =="n":
     is_running == False
     #this is the same thing as break  

    
    
    
  print("Thanks for using the Calculator, Bye bye...")
   #